
# Useful Python Functions

Compilation of useful python functions.

## Changelog

### v0.1.0
#### 9/13
 - Added changelog
 - Added menu function
 - Separated functions into different files
