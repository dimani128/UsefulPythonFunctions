
from time import sleep
from func_cls import cls

print("This text will dissapear in 2s.")
sleep(2)
cls()
print("It's gone!")